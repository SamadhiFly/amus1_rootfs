#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/mnt/build_root/usr/local/lib"
XML2_LIBS="-lxml2 -lz   -lm "
XML2_INCLUDEDIR="-I/mnt/build_root/usr/local/include/libxml2"
MODULE_VERSION="xml2-2.7.6"

